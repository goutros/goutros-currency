package net.goutros.goutroscurrency.network;

import net.goutros.goutroscurrency.ModAttachments;
import net.goutros.goutroscurrency.quest.PlayerQuestComponent;
import net.goutros.goutroscurrency.quest.Quest;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.network.handling.ClientPayloadContext;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.ArrayList;
import java.util.List;

public class QuestSyncPacket implements CustomPacketPayload {
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("goutroscurrency", "quest_sync");
    public static final CustomPacketPayload.Type<QuestSyncPacket> TYPE = new CustomPacketPayload.Type<>(ID);

    public final List<Quest> questQueue;
    public final List<Quest> activeQuests;

    public QuestSyncPacket(List<Quest> questQueue, List<Quest> activeQuests) {
        this.questQueue = questQueue;
        this.activeQuests = activeQuests;
    }

    @Override
    public Type<QuestSyncPacket> type() { return TYPE; }

    public static final StreamCodec<RegistryFriendlyByteBuf, QuestSyncPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, packet) -> {
                        CompoundTag tag = new CompoundTag();
                        ListTag queueList = new ListTag();
                        for (Quest q : packet.questQueue) queueList.add(q.toTag());
                        tag.put("questQueue", queueList);

                        ListTag activeList = new ListTag();
                        for (Quest q : packet.activeQuests) activeList.add(q.toTag());
                        tag.put("activeQuests", activeList);

                        buf.writeNbt(tag);
                    },
                    (buf) -> {
                        CompoundTag tag = buf.readNbt();
                        List<Quest> queue = new ArrayList<>();
                        List<Quest> active = new ArrayList<>();
                        if (tag != null) {
                            if (tag.contains("questQueue")) {
                                ListTag list = tag.getList("questQueue", CompoundTag.TAG_COMPOUND);
                                for (int i = 0; i < list.size(); i++)
                                    queue.add(Quest.fromTag((CompoundTag) list.get(i)));
                            }
                            if (tag.contains("activeQuests")) {
                                ListTag list = tag.getList("activeQuests", CompoundTag.TAG_COMPOUND);
                                for (int i = 0; i < list.size(); i++)
                                    active.add(Quest.fromTag((CompoundTag) list.get(i)));
                            }
                        }
                        return new QuestSyncPacket(queue, active);
                    }
            );

    public static void handle(QuestSyncPacket packet, ClientPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;

            @SuppressWarnings("unchecked")
            AttachmentType<PlayerQuestComponent> questType =
                    (AttachmentType<PlayerQuestComponent>)
                            NeoForgeRegistries.ATTACHMENT_TYPES.get(
                                    ResourceLocation.fromNamespaceAndPath("goutroscurrency", "player_quest"));
            if (questType == null) return;

            PlayerQuestComponent comp = mc.player.getData(questType);
            // Clear and repopulate both queue and active
            comp.getQueue().clear();
            comp.getQueue().addAll(packet.questQueue);

            comp.getActiveQuests().clear();
            for (Quest quest : packet.activeQuests)
                comp.getActiveQuests().add(quest);

            // No need to set preview—preview is always comp.getPreviewQuest()
        });
    }
}
