package net.goutros.goutroscurrency.quest;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

public class QuestEventsPlayerLifecycle {
    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            PlayerQuestComponent comp = PlayerQuestComponent.get(sp);
            if (comp != null) {
                QuestManager.ensureQuestQueueFilled(comp, sp.server, sp.getRandom(), 3);
                // Optionally: send a sync packet here!
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            PlayerQuestComponent comp = PlayerQuestComponent.get(sp);
            if (comp != null) {
                QuestManager.ensureQuestQueueFilled(comp, sp.server, sp.getRandom(), 3);
                // Optionally: send a sync packet here!
            }
        }
    }
}
