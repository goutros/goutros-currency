package net.goutros.goutroscurrency.quest;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.common.util.INBTSerializable;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.*;

public class PlayerQuestComponent implements INBTSerializable<CompoundTag> {
    // Persistent queue of future quests
    private final List<Quest> questQueue = new ArrayList<>();
    // Claimed quests (active or completed)
    private final Map<UUID, Quest> activeQuests = new LinkedHashMap<>();
    private Quest previewQuest; // Store the preview quest
    private long lastQuestTime = 0L; // Store the last quest time

    public List<Quest> getQueue() { return questQueue; }
    public Collection<Quest> getActiveQuests() { return activeQuests.values(); }
    public Quest getPreviewQuest() { return previewQuest; } // Get the preview quest

    // Set the preview quest
    public void setPreviewQuest(Quest previewQuest) {
        this.previewQuest = previewQuest;
    }

    public long getLastQuestTime() { return lastQuestTime; } // Get the last quest time
    public void setLastQuestTime(long lastQuestTime) { this.lastQuestTime = lastQuestTime; } // Set the last quest time

    public void claimNextQuest() {
        if (!questQueue.isEmpty()) {
            Quest quest = questQueue.remove(0);
            activeQuests.put(quest.getId(), quest);
        }
    }

    public void completeQuest(UUID id) {
        Quest quest = activeQuests.get(id);
        if (quest != null) quest.completed = true;
    }

    public void removeCompleted() {
        activeQuests.values().removeIf(Quest::isComplete);
    }

    public boolean hasActiveQuest(UUID id) { return activeQuests.containsKey(id); }
    public Quest getActiveQuest(UUID id) { return activeQuests.get(id); }

    // -- Serialization
    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider provider) {
        CompoundTag tag = new CompoundTag();
        // Save quest queue
        ListTag queueList = new ListTag();
        for (Quest q : questQueue) queueList.add(q.toTag());
        tag.put("questQueue", queueList);

        // Save active quests
        ListTag activeList = new ListTag();
        for (Quest q : activeQuests.values()) activeList.add(q.toTag());
        tag.put("activeQuests", activeList);

        // Save preview quest
        if (previewQuest != null) {
            tag.put("previewQuest", previewQuest.toTag());
        }

        // Save last quest time
        tag.putLong("lastQuestTime", lastQuestTime);

        return tag;
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider provider, CompoundTag nbt) {
        questQueue.clear();
        activeQuests.clear();
        ListTag queueList = nbt.getList("questQueue", Tag.TAG_COMPOUND);
        for (Tag t : queueList) questQueue.add(Quest.fromTag((CompoundTag) t));
        ListTag activeList = nbt.getList("activeQuests", Tag.TAG_COMPOUND);
        for (Tag t : activeList) {
            Quest quest = Quest.fromTag((CompoundTag) t);
            activeQuests.put(quest.getId(), quest);
        }
        if (nbt.contains("previewQuest")) {
            previewQuest = Quest.fromTag(nbt.getCompound("previewQuest"));
        }
        lastQuestTime = nbt.getLong("lastQuestTime"); // Deserialize last quest time
    }

    // Helper to get component
    public static PlayerQuestComponent get(Player player) {
        @SuppressWarnings("unchecked")
        AttachmentType<PlayerQuestComponent> type =
                (AttachmentType<PlayerQuestComponent>) NeoForgeRegistries.ATTACHMENT_TYPES.get(
                        ResourceLocation.fromNamespaceAndPath("goutroscurrency", "player_quest")
                );
        return type != null ? player.getData(type) : null;
    }
}
