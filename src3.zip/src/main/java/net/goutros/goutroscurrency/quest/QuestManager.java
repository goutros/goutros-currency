package net.goutros.goutroscurrency.quest;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.goutros.goutroscurrency.network.ModNetworking;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;

public class QuestManager {

    // Ensure the quest queue is filled with at least 'minQuests' quests.
    public static void ensureQuestQueueFilled(PlayerQuestComponent comp, MinecraftServer server, RandomSource rand, int minQuests) {
        while (comp.getQueue().size() < minQuests) {
            Quest newQuest = generateRandomGatherQuest(server, rand);
            if (newQuest != null)
                comp.getQueue().add(newQuest);
            else
                break;
        }
    }

    // Updates the preview quest and syncs the data with the client
    public static void updatePlayerQuestPreview(ServerPlayer player) {
        PlayerQuestComponent comp = PlayerQuestComponent.get(player);
        if (comp == null) return;

        // Ensure the quest queue is filled with at least 3 quests (or your desired number)
        ensureQuestQueueFilled(comp, player.server, player.getRandom(), 3);

        // Set the first quest in the queue as the preview quest
        Quest previewQuest = comp.getPreviewQuest();
        if (previewQuest == null && !comp.getQueue().isEmpty()) {
            previewQuest = comp.getQueue().get(0);  // Get the first quest in the queue if there's no preview
        }
        comp.setPreviewQuest(previewQuest);

        // Optionally: Send the updated quest data to the client
        ModNetworking.sendQuestSyncPacket(player, new ArrayList<>(comp.getQueue()), new ArrayList<>(comp.getActiveQuests()));
    }

    // Called when a player claims a quest from the board
    public static Quest claimNextQuest(Player player) {
        PlayerQuestComponent comp = PlayerQuestComponent.get(player);
        if (comp == null || comp.getQueue().isEmpty()) return null;
        Quest quest = comp.getQueue().get(0);
        comp.claimNextQuest(); // Moves quest from queue to activeQuests
        ensureQuestQueueFilled(comp, player.level().getServer(), player.getRandom(), 3); // Always refill the queue
        // Optionally: sync to client
        return quest;
    }

    // Generates a random "gather" quest, replace with your preset/config logic!
    public static Quest generateRandomGatherQuest(MinecraftServer server, RandomSource random) {
        String[] mats = {"minecraft:diamond", "minecraft:iron_ingot", "minecraft:gold_ingot"};
        String mat = mats[random.nextInt(mats.length)];
        int amount = 1 + random.nextInt(5);
        int coins = 5 + random.nextInt(10);
        return new Quest("gather", mat, amount, "Collect " + amount + "x " + mat, coins);
    }
}
